
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author santiago.castanop
 */
public class Registrar {
    public boolean registrar(Persona per) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        Persona per = new Persona();

        String sql = "INSERT INTO persona (id, nombre, telefono) VALUES(?,?,?)";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, per.getId());
            ps.setString(2, per.getNombre());
            ps.setString(3, per.getTelefono());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }
    public boolean Consultar() {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "select * from persona";
        try {
            ps = con.prepareStatement(sql);
            ps.executeQuery();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }
    public boolean buscar(int cedula) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();

        String sql = "SELECT * FROM persona WHERE id=? ";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, per.getId());
            rs = ps.executeQuery();

            if (rs.next()) {
                per.setId(Integer.parseInt(rs.getString("id")));
                per.setNombre(rs.getString("nombre"));
                per.setTelefono(rs.getString("telefono"));
                return true;
            }
            return false;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }
    
    public boolean Eliminar(int id) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "DELETE * FROM persona WHERE id=? ";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, id);
            ps.execute();

            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }
}

    

