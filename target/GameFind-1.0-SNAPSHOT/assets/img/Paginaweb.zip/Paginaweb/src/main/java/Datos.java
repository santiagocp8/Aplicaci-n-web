
import jakarta.jms.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author santiago.castanop
 */
public class Datos {
    public static Connection getConection() { 
    Connection con = null; 
    String base = "escuela"; 
    String url = "jdbc:mysql://localhost:3306/" + base; //Direccion, puerto y nombre de la Base de Datos 
    String user = "root"; //Usuario de Acceso a MySQL 
    String password = "password"; //
    try { 
        Class.forName("com.mysql.cj.jdbc.Driver"); 
        con = (Connection) DriverManager.getConnection(url, user, password); 
    } catch (ClassNotFoundException | SQLException e) { 
        System.err.println(e); 
    } return con; 
    }
    
}
